#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 03/28/2017
#Assignment-Number: Midterm Exam program 2
#Assignment Description:  This program display burgers for each person and leftover.
#                        
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

#(I)ask the user for the number of people attending the cookout
n_people = int(input('input number of people: '))
#(I)ask the user for the number of burgers each person will be given
n_burger = int(input('input number of burger per person: '))
#(P)calculates the number of packages of veggie burgers needed for the cookout
vb = n_people/4
#(P)calculate the number of packages of burger buns needed for a cookout
bb = n_people/6
#(P)calculate the minimum amount of leftovers vb
l_vb = n_people % 4
#(P)calculate the minimum amount of leftovers bb
l_bb = n_people % 6
#(O)The minimum number of packages of veggie burgers required
print('The minimum number of packages of veggie burgers required', format(vb, '.1f'))
#(O)The minimum number of packages of burgers buns required
print('The minimum number of packages of burgers buns required', format(bb, '.0f'))
#(O)The number of veggie burgers that will be left over
print('The number of veggie burgers that will be left over', l_vb)
#(O)The number of burgers buns that will be left over
print('The number of veggie burgers that will be left over', l_bb)
