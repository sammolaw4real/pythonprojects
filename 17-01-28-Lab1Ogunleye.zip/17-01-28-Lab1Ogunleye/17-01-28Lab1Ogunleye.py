#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 01/28/2017
#Assignment-Number: HW 1, Lab 1
#Assignment Description: input and output of the user first name and last name.
#
#
#
#Ver no.      Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization
#
#1.	(I) Input first name
my_first_name = input(' Please input first name: ')
#2.	(I) Input last name
my_last_name =  input(' Please input last name: ')
#3.	(o) Display Hello fname lname
print('Hello', my_first_name, my_last_name)

#print('This happens to be my first python program')
