#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/19/2017
#Assignment-Number: Program 4-6
#Assignment Description: This program is written to demonstrates a simple for loop
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program also demonstrates a simple for loop that uses a list of strings.

for name in ['Winken', 'Blinken', 'Nod']:
    print(name)


