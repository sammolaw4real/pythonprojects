#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/19/2017
#Assignment-Number: Program 4-7
#Assignment Description: This program demonstrates how the range function can be used with a for loop.
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program demonstrates how the range function can be used with a for loop.

# Print a message five times.
for x in range(5):
    print('Hello world')


