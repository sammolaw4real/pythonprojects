#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/19/2017
#Assignment-Number: Program 4-10
#Assignment Description: This program uses a loop to display a table of numbers and their squares.
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program uses a loop to display a table of numbers and their squares.

# Get the ending limit.
print('This program displays a list of numbers')
print('(starting at 1) and their squares.')
end = int(input('How high should I go?'))

# Print the table headings.
print()
print('Number\tSquare')
print('--------------')

# Print the numbers and their squares.
for number in range(1, end + 1):
    square = number**2
    print(number, '\t', square)
