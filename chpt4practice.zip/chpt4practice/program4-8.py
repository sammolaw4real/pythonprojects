#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/19/2017
#Assignment-Number: Program 4-8
#Assignment Description: This program demonstrates how the range function can be used with a for loop.
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program uses a loop to display a table showing the numbers 1 through 10
# and their squares.

# Print the table headings.
print('Number\tSquare')
print('--------------')

# Print the numbers 1 through 10 and their squares.
for number in range(1, 11):
    square = number**2
    print(number, '\t', square)
