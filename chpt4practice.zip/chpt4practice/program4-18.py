#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/19/2017
#Assignment-Number: Program 4-18
#Assignment Description: This program displays a rectangular pattern of asterisks.
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program displays a rectangular pattern of asterisks.
rows = int(input('How many rows? '))

for r in range(rows):
    for c in range(r + 1):
        print('*', end='')
    print()
