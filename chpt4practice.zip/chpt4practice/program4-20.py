#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/19/2017
#Assignment-Number: Program 4-20
#Assignment Description: This program displays a stair−step pattern.
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program displays a stair−step pattern.
num_steps = 6

for r in range(num_steps):
    for c in range(r):
        print('*', end='')
    print('')
