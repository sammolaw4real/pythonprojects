#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/02/2017
#Assignment-Number: Program 2-2
#Assignment Description: output name and address.
#
#
#
#Ver no.      Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

print("Kate Austen")
print("123 Full Circle Drive")
print("Asheville, NC 28899")
