#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/02/2017
#Assignment-Number: Program 2-21
#Assignment Description: Program is written to align values in column
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program demonstrates how a floating-point
# number can be displayed as currency.
monthly_pay = 5000.0
annual_pay = monthly_pay * 12
print('Your annual pay is $', \
format(annual_pay, ',.2f'), \
 sep='')

