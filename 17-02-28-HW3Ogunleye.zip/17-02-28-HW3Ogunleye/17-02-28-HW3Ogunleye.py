#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/27/2017
#Assignment-Number: HW3
#Assignment Description: Program is written to simulate a vending machine.
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

#(O) Display the available options in the vending machine
#along with the price (minimum of  5items).
print('Welcome valued customer!')
print('Thank you for stopping by')
print('Please use the codes in front of each drinks to select and pay for the kind of drink you want')
print('----------------------------------------------------------------------------------------------')
print('Coke  (d1) price = $1.25')
print('Pepsi (d2) price = $1.25')
print('Fanta (d3) price = $1.25')
print('Sprite(d4) price = $1.25')
print('Water (d5) price = $1.00')

#Assign variables
coke = 'd1'
pepsi = 'd2'
fanta = 'd3'
sprite = 'd4'
water = 'd5'

#(I) customer selects an item code for purchase
select_choice = (input('Enter the code of your desired drink: '))

#(I) system should prompt to insert any bill
if select_choice == coke:
    print('Amount due for this product is $1.25')
    amount_paid = float(input('please insert bill: '))
    
#(P) Reject the transaction if the bill amount is lower than the selected item’s price
    while amount_paid < 1.25:                                                                 
        print('-----------------ERROR---------------')
        print('Amount not enough for product')
        print('Please make sure amount is "$1.25" or more')
        print('Start purchase of drink again')
        amount_paid = float(input('please insert bill: '))
        
#(P) machine dispenses the change in coins of
#denominations 1cent, 5cents, 10cents, 25cents & 1dollar
#(P) Calculate the change for minimum number of coins and dispense
    if amount_paid == 1.25:
        print('Take your drink "COKE" ')
    elif amount_paid > 1.25:
        change = amount_paid - 1.25
    
#(O) Display the change amount and the number of coins dispensed by denomination.
        print('Take your drink "COKE" ')
        print('Change amount is: $', format(change, '.2f'), 'cents')
           
#Check if customer want to buy pepsi                    
elif select_choice == pepsi:
    print('Amount due for this product is $1.25')
    amount_paid = float(input('please insert bill: '))

#(P) Reject the transaction if the bill amount is lower than the selected item’s price
    while amount_paid < 1.25:                                                                 
        print('-----------------ERROR---------------')
        print('Amount not enough for product')
        print('Please make sure amount is "$1.25" or more')
        print('Start purchase of drink again')
        amount_paid = float(input('please insert bill: '))
        
#(P) machine dispenses the change in coins of
#denominations 1cent, 5cents, 10cents, 25cents & 1dollar
#(P) Calculate the change for minimum number of coins and dispense
    if amount_paid == 1.25:
        print('Take your drink "PEPSI" ')
    elif amount_paid > 1.25:
        change = amount_paid - 1.25
    
#(O) Display the change amount and the number of coins dispensed by denomination.
        print('Take your drink "PEPSI" ')
        print('Change amount is: $', format(change, '.2f'), 'cents')

#Check if customer want to buy fanta
elif select_choice == fanta:
    print('Amount due for this product is $1.25')
    amount_paid = float(input('please insert bill: '))
#(P) Reject the transaction if the bill amount is lower than the selected item’s price
    while amount_paid < 1.25:                                                                 
        print('-----------------ERROR---------------')
        print('Amount not enough for product')
        print('Please make sure amount is "$1.25" or more')
        print('Start purchase of drink again')
        amount_paid = float(input('please insert bill: '))
        
#(P) machine dispenses the change in coins of
#denominations 1cent, 5cents, 10cents, 25cents & 1dollar
#(P) Calculate the change for minimum number of coins and dispense
    if amount_paid == 1.25:
        print('Take your drink "FANTA" ')
    elif amount_paid > 1.25:
        change = amount_paid - 1.25
    
#(O) Display the change amount and the number of coins dispensed by denomination.
        print('Take your drink "FANTA" ')
        print('Change amount is: $', format(change, '.2f'), 'cents')

#Check if customer wants to buy sprite    
elif select_choice == sprite:
    print('Amount due for this product is $1.25')
    amount_paid = float(input('please insert bill: '))

#(P) Reject the transaction if the bill amount is lower than the selected item’s price
    while amount_paid < 1.25:                                                                 
        print('-----------------ERROR---------------')
        print('Amount not enough for product')
        print('Please make sure amount is "$1.25" or more')
        print('Start purchase of drink again')
        amount_paid = float(input('please insert bill: '))
        
#(P) machine dispenses the change in coins of
#denominations 1cent, 5cents, 10cents, 25cents & 1dollar
#(P) Calculate the change for minimum number of coins and dispense
    if amount_paid == 1.25:
        print('Take your drink "SPRITE" ')
    elif amount_paid > 1.25:
        change = amount_paid - 1.25
    
#(O) Display the change amount and the number of coins dispensed by denomination.
        print('Take your drink "SPRITE" ')
        print('Change amount is: $', format(change, '.2f'), 'cents')

#Check if customer wants to buy water
elif select_choice == water:
    print('Amount due for this product is $1.00')
    amount_paid = float(input('please insert bill: '))

#(P) Reject the transaction if the bill amount is lower than the selected item’s price
    while amount_paid < 1.25:                                                                 
        print('-----------------ERROR---------------')
        print('Amount not enough for product')
        print('Please make sure amount is "$1.25" or more')
        print('Start purchase of drink again')
        amount_paid = float(input('please insert bill: '))
        
#(P) machine dispenses the change in coins of
#denominations 1cent, 5cents, 10cents, 25cents & 1dollar
#(P) Calculate the change for minimum number of coins and dispense
    if amount_paid == 1.25:
        print('Take your drink "water" ')
    elif amount_paid > 1.25:
        change = amount_paid - 1.25
    
#(O) Display the change amount and the number of coins dispensed by denomination.
        print('Take your drink "WATER" ')
        print('Change amount is: $', format(change, '.2f'), 'cents')
                
                
            
