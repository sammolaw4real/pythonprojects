#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/14/2017
#Assignment-Number class work 1
#Assignment Description: 
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization
#
#1.	(I) Input first value
firstValue = int(input('Enter first value = '))
#2(I) Input second value
secondValue = int(input('Enter second value = '))
#3(P) Calculate the values entered: 
diff = firstValue - secondValue
#4(O) Display “The sum of the two numbers is =” 15
print(  firstValue ,"-", secondValue, " = ", diff) 

