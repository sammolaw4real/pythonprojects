fb = '"best".'
print("Python's the", fb)
