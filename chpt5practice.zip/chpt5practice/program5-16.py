#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 03/15/2017
#Assignment-Number: Program 5-16
#Assignment Description: This program displays a random number.
#                        
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program displays a random number
# in the range of 1 through 10.
import random

def main():
# Get a random number.
    number = random.randint(1, 10)
# Display the number.
    print('The number is', number)

# Call the main function.
main()
