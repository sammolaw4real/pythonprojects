#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 03/15/2017
#Assignment-Number: Program 5-18
#Assignment Description: This program displays five random
#                        
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program displays five random
# numbers in the range of 1 through 100.
import random

def main():
    for count in range(5):
        print(random.randint(1, 100))

# Call the main function.
main()
