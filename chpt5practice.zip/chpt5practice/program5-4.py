#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 03/15/2017
#Assignment-Number: Program 5-4
#Assignment Description: This program shows error in assigning local variables.
#                        
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# Definition of the main function.
def main():
    get_name()
    print('Hello', name) # This causes an error!

# Definition of the get_name function.
def get_name():
    name = input('Enter your name: ')

# Call the main function.
main()
