#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 03/15/2017
#Assignment-Number: Program 5-5
#Assignment Description: This program is about two function.
#                        
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

#This program demonstrates two functions that
 # have local variables with the same name.

def main():
# Call the texas function.
    texas()
# Call the california function.
    california()

# Definition of the texas function. It creates
# a local variable named birds.
def texas():
    birds = 5000
    print('texas has', birds, 'birds.')
    
    # Definition of the california function. It also
    # creates a local variable named birds.
def california():
    birds = 8000
    print('california has', birds, 'birds.')

# Call the main function.
main()
