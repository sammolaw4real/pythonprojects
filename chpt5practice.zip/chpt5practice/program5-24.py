#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 03/15/2017
#Assignment-Number: Program 5-24
#Assignment Description: This program demonstrates the sqrt function.
#                        
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# This program demonstrates the sqrt function.
import math

def main():
# Get a number.
    number = float(input('Enter a number: '))

# Get the square root of the number.
    square_root = math.sqrt(number)

# Display the square root.
    print('The square root of', number, 'is', square_root)

# Call the main function.
main()
