#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 03/07/2017
#Assignment-Number: HW4
#Assignment Description: Program is written to sum even numbers using while loop.
#
#
#
#Ver no.         Name(Initials)     Date                        Description
#========     ===========    ==========         ===============
#
#**********************************************************
#Variable Initialization

sum = 0
q_user = 'yes'

#Ask user if he/she wants to enter a new number
q_user = input('Do you want to enter a new numher? ')
if q_user == 'yes':
    while q_user == 'yes':

#Asks the user to input a number
        entry = int(input('Input a number: '))

#If the number is even, it adds this number to previously entered even number
        if (entry % 2) == 0:
            sum += entry
            print ('The total is ' + str(sum))

#It displays "It is not an even number"
        else:
            print ('It is not an even number')
        q_user = input('Do you want to enter a new numher? ')

#Terminate program
else:
    print('HAVE A NICE BYE!!!')
    
