#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/11/2017
#Assignment-Number: HW2
#Assignment Description: This program display number of miles a car could go by multiplying the miles per gallon
#                         and number of gas in tank
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

#(I)	The number of gallons of the gas in the tank
number_gallon_gas = float(input('Enter number of gallons of gas in your tank = '))
#(I)	MPG of the car
m_p_g = int(input('Enter number of miles per gas = '))
#(P)       Miles = MPG x Gallons of gas in the tank
miles = m_p_g * number_gallon_gas
#(O)      displays the miles the car can go
print('Miles the can go is: ', miles)
