#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/02/2017
#Assignment-Number: Program 2-6
#Assignment Description: Putting comment in programs
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

print('Kate Austen')            # Display the name.
print('123 Full Circle Drive')  # Display the address.
print('Asheville, NC 28899')    # Display the city, state, and ZIP.
