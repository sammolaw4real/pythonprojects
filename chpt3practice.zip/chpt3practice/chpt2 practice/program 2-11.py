#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/02/2017
#Assignment-Number: Program 2-11
#Assignment Description: Program to create variables to reference two strings 
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# Create variables to reference two strings.
first_name = 'Kathryn'
last_name = 'Marino'

#Display the values referenced by the variables.
print(first_name, last_name)
