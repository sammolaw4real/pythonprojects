#**********************************************************
#class: IT-512 Spring 2017
#Author: Samson Ogunleye
#Due Date: 02/02/2017
#Assignment-Number: Program 2-14
#Assignment Description: Program is to add two values that are hardcoded
#
#
#
#Ver no.         Name(Initials)     Date			Description
#========     ===========    ==========		===============
#
#**********************************************************
#Variable Initialization

# Assign a value to the salary variable.
salary = 2500.0

# Assign a value to the bonus variable.
bonus = 1200.0

#Calculate the total pay by adding salary and bonus. Assign the result to pay.
pay = salary + bonus

# Display the pay.
print('Your pay is', pay)
