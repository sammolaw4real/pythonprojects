Python 3.5.3 (v3.5.3:1880cb95a742, Jan 16 2017, 16:02:32) [MSC v.1900 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
==== RESTART: C:/Users/Sammy/Desktop/IT-512/chpt2 practice/Program 2-1.py ====
Kate Austen
123 Full Circle Drive
Asheville, NC 28899
>>> 
